function scanRFID() {
    const input = document.getElementById('rfidInput').value;
    document.getElementById('result').innerText = 
        input ? `RFID Tag ${input} scanned successfully!` : "Please enter a Tag ID.";
}